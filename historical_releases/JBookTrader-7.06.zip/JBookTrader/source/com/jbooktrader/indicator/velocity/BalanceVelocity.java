package com.jbooktrader.indicator.velocity;

import com.jbooktrader.indicator.depth.*;
import com.jbooktrader.platform.indicator.*;
import com.jbooktrader.platform.marketbook.*;

/**
 * Velocity of balance
 */
public class BalanceVelocity extends Indicator {
    private final double fastMultiplier, slowMultiplier;
    private double fast, slow;
    private DepthBalance depthBalance;

    public BalanceVelocity(int fastPeriod, int slowPeriod) {
        fastMultiplier = 2.0 / (fastPeriod + 1.0);
        slowMultiplier = 2.0 / (slowPeriod + 1.0);
    }

    @Override
    public void setMarketBook(MarketBook marketBook) {
        super.setMarketBook(marketBook);
        depthBalance = new DepthBalance();
        depthBalance.setMarketBook(marketBook);
    }

    @Override
    public void calculate() {
        depthBalance.calculate();
        double depthBalanceValue = depthBalance.getValue();
        fast += (depthBalanceValue - fast) * fastMultiplier;
        slow += (depthBalanceValue - slow) * slowMultiplier;

        value = fast - slow;
    }

    @Override
    public void reset() {
        fast = slow = value = 0;
    }
}
